# Installation of the Paleomass package

## Option 1.
Install from the pakcage file. 

-Windows binary package is available [here.](./paleomass_0.9.5.0000.zip)   

-Source package is available [here.](./paleomass_0.9.5.0000.tar.gz)

In RStudio, open the package installtion dialog. In the top pulldown menu named "Install from" choose "Package Archive File".

## Option 2.
Not available yet. Once the repository is public, try:

``` 
`library(devtools)
`devtools::install_github("rmotani/paleomass")`
```

